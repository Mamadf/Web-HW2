import React, { useRef, useEffect } from 'react';
import { drawShape, isPointInTriangle } from '../utils/shapeUtils';

const Canvas = ({ shapes, setShapes, dragShape, setDragShape }) => {
  const canvasRef = useRef(null);
  const clickTimeout = useRef(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    canvas.width = 300;
    canvas.height = 200;
  }, []);

  useEffect(() => {
    const ctx = canvasRef.current.getContext('2d');
    ctx.clearRect(0, 0, 300, 200);
    shapes.forEach(shape => drawShape(ctx, shape));
  }, [shapes]);

  const handleDrop = (e) => {
    e.preventDefault();
    if (!dragShape) return;

    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newShape = { type: dragShape, x, y };
    setShapes(prev => [...prev, newShape]);
    setDragShape(null);
  };

  const handleDoubleClick = (e) => {
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setShapes(prev => prev.filter(shape => {
      if (shape.type === 'rectangle') {
        return !(x > shape.x - 50 && x < shape.x + 50 && y > shape.y - 25 && y < shape.y + 25);
      } else if (shape.type === 'circle') {
        const dx = x - shape.x, dy = y - shape.y;
        return dx * dx + dy * dy > 1600;
      } else if (shape.type === 'triangle') {
        return !isPointInTriangle(x, y, shape);
      }
      return true;
    }));
  };

  return (
    <div style={{ flex: 1, border: '1px solid #ccc', margin: '10px' }} onDrop={handleDrop} onDragOver={(e) => e.preventDefault()}>
      <canvas ref={canvasRef} onDoubleClick={handleDoubleClick} style={{ width: '100%', height: '100%', display: 'block' }} />
    </div>
  );
};

export default Canvas;