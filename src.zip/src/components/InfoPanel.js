import React from 'react';

const InfoPanel = ({ shapeCounts }) => (
  <div style={{ backgroundColor: '#e0e0e0', padding: '10px' }}>
    <h3>Information</h3>
    <p>Drag shapes from the tools section and drop them onto the canvas. Shapes will be centered at the drop point.</p>
    <p>Rectangle: {shapeCounts.rectangle}</p>
    <p>Circle: {shapeCounts.circle}</p>
    <p>Triangle: {shapeCounts.triangle}</p>
  </div>
);

export default InfoPanel;